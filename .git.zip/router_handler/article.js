exports.addArticle = (req, res) => {
	res.send('发布文章成功')
}