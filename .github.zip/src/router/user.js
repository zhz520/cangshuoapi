const express = require('express')

const router = express.Router()

const user_handlers = require('../router_handler/user')

const expressJoi = require('@escook/express-joi')

const { reg_login_schema, send_email_schema } = require('../schems/user')
// 注册新用户
router.post('/register', expressJoi(reg_login_schema), user_handlers.regUser)
// 登录
router.post('/login', expressJoi(reg_login_schema), user_handlers.login)
// 发送邮件给管理员
router.post('/sendEmailToAdmin', expressJoi(send_email_schema), user_handlers.sendEmailToAdmin)


// 获取王者英雄列表
router.get('/getHeroList', user_handlers.getHeroList)

// 蓝奏直链解析
router.get('/getLanZouLink', user_handlers.getLanZouLink)

// 快手视频解析
router.get('/getKuaishouLink', user_handlers.getKuaishouLink)

// 抖音视频解析
router.get('/getDouyinLink', user_handlers.getDouyinLink)

// 获取QQ小世界作者QQ号
router.get('/getQQAuthor', user_handlers.getQQAuthor)

module.exports = router